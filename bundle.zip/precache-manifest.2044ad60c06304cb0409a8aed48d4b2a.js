self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "419ad4b484223613ad1fbddfd28a11af",
    "url": "/r/index.html"
  },
  {
    "revision": "343005e2b35eff5fd767",
    "url": "/r/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "6ec48e054ad6f35b8357",
    "url": "/r/static/css/main.4bc43af8.chunk.css"
  },
  {
    "revision": "343005e2b35eff5fd767",
    "url": "/r/static/js/2.a27ab5c5.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/r/static/js/2.a27ab5c5.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6ec48e054ad6f35b8357",
    "url": "/r/static/js/main.c0caa871.chunk.js"
  },
  {
    "revision": "f74b98a44476aef97f09",
    "url": "/r/static/js/runtime-main.e1d1d6a4.js"
  }
]);